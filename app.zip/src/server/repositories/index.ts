import "server-only";

import type { SessionRepo } from "./sessionRepo";
import type { UserRepo } from "./userRepo";

import { InMemorySessionRepo } from "./memory/sessionRepo.memory";
import { InMemoryUserRepo, createDevSeedUser } from "./memory/userRepo.memory";

/**
 * Repository composition root.
 *
 * Auth v1 uses in-memory repositories (documented in docs/auth.md).
 * Later we can swap implementations (e.g., MongoDB) without changing
 * services or API routes.
 *
 * Important: Keep these as singletons so sessions/users persist for the
 * lifetime of the server runtime (within the limits of serverless).
 */

const isProd = process.env.NODE_ENV === "production";

/**
 * Optional dev seed user.
 *
 * For local testing you can provide:
 * - AUTH_DEV_SEED_EMAIL
 * - AUTH_DEV_SEED_PASSWORD_HASH (Argon2id encoded hash)
 *
 * Security:
 * - Seeding is disabled in production.
 * - Never commit real passwords.
 */
function getDevSeedUsers() {
  if (isProd) return [];

  const email = process.env.AUTH_DEV_SEED_EMAIL?.trim();
  const passwordHash = process.env.AUTH_DEV_SEED_PASSWORD_HASH?.trim();

  if (!email || !passwordHash) return [];

  return [createDevSeedUser({ email, passwordHash })];
}

// --- Singleton instances ---

export const sessionRepo: SessionRepo = new InMemorySessionRepo();

export const userRepo: UserRepo = new InMemoryUserRepo(getDevSeedUsers());
