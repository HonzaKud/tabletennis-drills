import "server-only";

import crypto from "node:crypto";
import type { UserId, UserRecord, UserRepo } from "../userRepo";

/**
 * In-memory user repository (Auth v1).
 *
 * Notes:
 * - Intended for MVP / demo purposes.
 * - Users are stored in-process and will be lost on server restart.
 * - Email lookups are case-insensitive.
 * - Includes a simple dev seed user for immediate testing.
 */

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export class InMemoryUserRepo implements UserRepo {
  private readonly usersById = new Map<UserId, UserRecord>();
  private readonly usersByEmail = new Map<string, UserRecord>();

  constructor(seedUsers?: Array<Omit<UserRecord, "id" | "createdAt">>) {
    if (seedUsers && seedUsers.length > 0) {
      for (const user of seedUsers) {
        this.insert({
          ...user,
          id: this.generateUserId(),
          createdAt: new Date(),
        });
      }
    }
  }

  async findByEmail(email: string): Promise<UserRecord | null> {
    const key = normalizeEmail(email);
    return this.usersByEmail.get(key) ?? null;
  }

  async findById(id: UserId): Promise<UserRecord | null> {
    return this.usersById.get(id) ?? null;
  }

  /**
   * Insert a new user record.
   * Internal helper (not part of UserRepo interface).
   */
  private insert(user: UserRecord): void {
    const emailKey = normalizeEmail(user.email);

    const record: UserRecord = {
      ...user,
      email: emailKey,
      isActive: user.isActive ?? true,
    };

    this.usersById.set(record.id, record);
    this.usersByEmail.set(emailKey, record);
  }

  private generateUserId(): UserId {
    // Simple opaque identifier; can be replaced by DB-generated IDs later.
    return crypto.randomUUID();
  }
}

/**
 * Helper to create a dev-only seed user.
 *
 * Usage:
 * - Generate a password hash once (e.g. via script or temporary code)
 * - Paste the hash here for local testing
 *
 * IMPORTANT:
 * - Never commit real passwords.
 * - This is for local development only.
 */
export function createDevSeedUser(params: {
  email: string;
  passwordHash: string;
}): Omit<UserRecord, "id" | "createdAt"> {
  return {
    email: params.email,
    passwordHash: params.passwordHash,
    isActive: true,
  };
}
