import "server-only";

import crypto from "node:crypto";
import type {
  CreateSessionParams,
  SessionId,
  SessionRecord,
  SessionRepo,
} from "../sessionRepo";

/**
 * In-memory session repository (Auth v1).
 *
 * Notes:
 * - Suitable for MVP / demo purposes.
 * - Sessions are stored in-process and will be lost on server restart
 *   (expected for Auth v1, documented in docs/auth.md).
 * - Includes basic cleanup for expired sessions.
 */
export class InMemorySessionRepo implements SessionRepo {
  private readonly sessions = new Map<SessionId, SessionRecord>();

  async create(params: CreateSessionParams): Promise<SessionRecord> {
    const now = new Date();

    // Opportunistic cleanup to prevent unbounded growth.
    await this.deleteExpired(now);

    const sessionId = this.generateSessionId();
    const record: SessionRecord = {
      sessionId,
      userId: params.userId,
      createdAt: now,
      expiresAt: params.expiresAt,
    };

    this.sessions.set(sessionId, record);
    return record;
  }

  async get(sessionId: SessionId): Promise<SessionRecord | null> {
    const record = this.sessions.get(sessionId) ?? null;
    if (!record) return null;

    // Auto-expire on read.
    const now = new Date();
    if (record.expiresAt.getTime() <= now.getTime()) {
      this.sessions.delete(sessionId);
      return null;
    }

    return record;
  }

  async delete(sessionId: SessionId): Promise<boolean> {
    return this.sessions.delete(sessionId);
  }

  async deleteExpired(now: Date = new Date()): Promise<number> {
    let removed = 0;
    for (const [id, record] of this.sessions.entries()) {
      if (record.expiresAt.getTime() <= now.getTime()) {
        this.sessions.delete(id);
        removed += 1;
      }
    }
    return removed;
  }

  private generateSessionId(): SessionId {
    // 32 bytes = 256 bits of entropy; URL-safe base64.
    return crypto.randomBytes(32).toString("base64url");
  }
}
